#pragma once
namespace ImGui {
	namespace Custom {
		extern bool FancyToggle(const char* label, bool* v);
	}
}