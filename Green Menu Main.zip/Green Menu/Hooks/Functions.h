#pragma once


//add wtv functions you want here.

void doFunction() {
	Pointers::Example::ExampleLayout.ExamplePointer_Static(999); //Example calling pointer
}