#include "Vars.h"



bool exampleToggle;


