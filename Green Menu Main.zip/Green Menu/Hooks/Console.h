#pragma once
#include <iostream>
#include <Windows.h>

namespace CMD {
	void Load();
}