#include "ExampleLayout.h"

namespace Pointers::Example {
	U_ExampleLayout ExampleLayout;
}
