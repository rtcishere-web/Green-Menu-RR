# DX11 ImGui Template
DX11 ImGui Template

Simple to use DX11 ImGui template

Everything is setup simple to use, you don't really need to touch a lot.


# Features
- Newer ImGui added (1.91.8 | Original rdbo template has old ImGui version)
- Macro for simple hooking
- Insert & Delete key menu toggles (Can be changed to any key)
- Cursor Detach on menu open
- Custom Toggles implemented if you dont want checkboxes
- Console Setup - (Can be easily removed)
- Example menus

- MORE IS BEING ADDED SOON!

# Libraries Added
- ImGui (Win32 & DX11 backends)
- Kiero (Used to hook present for rendering)
- MinHook (for inline hooking, for your game mods)

# Credits
- https://github.com/rdbo/ImGui-DirectX-11-Kiero-Hook (Base)
- https://github.com/Rebzzel/kiero (Hook Library)
- https://github.com/TsudaKageyu/minhook (Hook Library)
- https://github.com/ocornut/imgui (GUI Library)

# TO-DO
- [ ] Import Basic Mono & Unity Structs
- [ ] Neaten Code
- [ ] Add dedicated ByNameModding Library, most likely IL2CPP resolver
- [ ] Add simple manager for pushing in & out player objects with hooking
- [ ] IOS & Android ports of this template
- [ ] Support for other graphical backends - (Vulkan, OpenGL, DirectX <= 10) 
